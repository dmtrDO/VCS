require("config.lazy")
require("config.options")
require("config.keybinds")
vim.cmd.colorscheme("colorscheme")

