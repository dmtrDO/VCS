return {
  {
    "mfussenegger/nvim-dap",
    dependencies = {
      "mfussenegger/nvim-dap-python",
      "rcarriga/nvim-dap-ui",
      "nvim-neotest/nvim-nio",
    },
    config = function()
      local dap = require("dap")
      local dapui = require("dapui")

      require("dap-python").setup("python")  -- or full path: ".venv/bin/python"

      dapui.setup()

      dap.listeners.after.event_initialized["dapui_config"] = function()
        dapui.open()
      end
      dap.listeners.before.event_terminated["dapui_config"] = function()
        dapui.close()
      end
      dap.listeners.before.event_exited["dapui_config"] = function()
        dapui.close()
      end

      vim.keymap.set("n", "<leader>c", dap.continue, { desc = "Debug: Continue" })
      vim.keymap.set("n", "<leader>sr", dap.step_over, { desc = "Debug: Step Over" })
      vim.keymap.set("n", "<leader>si", dap.step_into, { desc = "Debug: Step Into" })
      vim.keymap.set("n", "<leader>st", dap.step_out, { desc = "Debug: Step Out" })
      vim.keymap.set("n", "<C-b>", dap.toggle_breakpoint, { desc = "Debug: Toggle Breakpoint" })
      vim.keymap.set("n", "<leader>r", dap.repl.open, { desc = "Debug: Open REPL" })
      vim.keymap.set("n", "<leader>t", dap.terminate, { desc = "Debug: Terminate" })
    end,
  },
}
