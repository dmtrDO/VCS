
local function enable_transparency()
    vim.api.nvim_set_hl(0, "Normal", { bg = "none" })
end
return {
    {
	"folke/tokyonight.nvim",
	config = function()
	    vim.cmd.colorscheme "tokyonight"
	    enable_transparency()
	end
    },	
    {
	"nvim-lualine/lualine.nvim",
	opts = {
	    theme = "tokyonight",
	    sections = {
		lualine_a = { 'mode' },
		lualine_b = { 'branch', }, -- diagnostics, diff removed
		lualine_c = { 'filename', },
		lualine_x = { 'encoding', 'filetype' }, -- fileformat removed
		lualine_y = {}, -- progress removed
		lualine_z = { 'location', },
	    },
	}
    }
}



