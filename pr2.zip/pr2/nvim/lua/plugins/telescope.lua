os.setlocale("C", "time")

local check_filename = function(prompt_bufnr)
    local action_state = require("telescope.actions.state")
    local selection = action_state.get_selected_entry()
    if selection == nil then return end
    local filepath = selection.path or selection[1]
    local filename = vim.fs.basename(filepath)
    print(filename)
end

local open_as_hex = function(prompt_bufnr)
    local action_state = require("telescope.actions.state")
    local actions = require("telescope.actions")
    local selection = action_state.get_selected_entry()
    if selection == nil then return end
    local filepath = selection.path or selection[1]
    
    -- 1. Expand to absolute path to correctly locate directories
    if not filepath then return end
	filepath = vim.fn.fnamemodify(filepath, ":p")
    
    actions.close(prompt_bufnr)

    local f = io.open(filepath, "rb")
    if not f then return end
    local bytes = f:read("*all")
    f:close()
    if not bytes then return end

    local lines = {}
    local current_line = {}
    local bytes_per_line = 12

    for i = 1, #bytes do
        table.insert(current_line, string.format("0x%02x", string.byte(bytes, i)))
        if i % bytes_per_line == 0 then
            table.insert(lines, table.concat(current_line, " "))
            current_line = {}
        end
    end

    if #current_line > 0 then
        table.insert(lines, table.concat(current_line, " "))
    end

    -- Check if a buffer with this exact hex name already exists and delete it
    local bufname = "Hex: " .. vim.fs.basename(filepath)
    local existing_buf = vim.fn.bufnr(bufname)
    if existing_buf ~= -1 and vim.api.nvim_buf_is_valid(existing_buf) then
        pcall(vim.api.nvim_buf_delete, existing_buf, { force = true })
    end

    -- Create and populate scratch buffer
    local bufnr = vim.api.nvim_create_buf(true, true)
    vim.api.nvim_buf_set_name(bufnr, "Hex: " .. vim.fs.basename(filepath))
    vim.api.nvim_buf_set_lines(bufnr, 0, -1, false, lines)
    vim.bo[bufnr].modifiable = false
    vim.bo[bufnr].readonly = true
    vim.api.nvim_set_current_buf(bufnr)

    -- Lock the current window's local directory (lcd) to the file's folder
    local dir = vim.fs.dirname(filepath)
    if dir and dir ~= "" then
        vim.cmd("lcd " .. vim.fn.fnameescape(dir))
    end

end

local custom_open = function(prompt_bufnr)
    local action_state = require("telescope.actions.state")
    local actions = require("telescope.actions")
    local selection = action_state.get_selected_entry()
    if selection == nil then return end
    
    local filepath = selection.path or selection[1]
    if not filepath then return end
    filepath = vim.fn.fnamemodify(filepath, ":p")

    local ext = filepath:match("^.+(%..+)$")
    if ext then ext = ext:lower() end
    local binary_extensions = {
	[".pdf"] = true, [".png"] = true, [".jpg"] = true, [".jpeg"] = true, [".gif"] = true,
	[".mp4"] = true, [".docx"] = true, [".doc"] = true, [".pptx"] = true, [".xlsx"] = true,
	[".npz"] = true,
    }

    if binary_extensions[ext] then
	vim.fn.jobstart({ "explorer.exe", filepath }, { detach = true })
    else
	actions.select_default(prompt_bufnr)
    end

end

return {
    'nvim-telescope/telescope.nvim',
    tag = 'v0.1.9',
    dependencies = {
	'nvim-lua/plenary.nvim',
	'nvim-telescope/telescope-file-browser.nvim',
	{ "iruzo/ripgrep.nvim", build = ":lua require('rg_setup').install_rg()" },
    },

    config = function()
	require('telescope').setup({
	    defaults = {
		buffer_previewer_maker = require("config.telescope_previewer")(),
		layout_config = { width = 0.95, height = 0.95 },
		initial_mode = "normal",
		mappings = {
		    i = {
			["<CR>"] = custom_open,
		    },
		    n = {
			["<CR>"] = custom_open,
			["o"] = open_as_hex,
			["n"] = check_filename,
		    },
		},
	    },
	    pickers = {
		find_files = {
		    hidden = true,
		    no_ignore = true,
		    initial_mode = "insert",
		    layout_config = { preview_width = 0.40, },
		},
		live_grep = {
		    initial_mode = "insert",
		    layout_config = { preview_width = 0.40, },
		},
		oldfiles = {
		    layout_config = { preview_width = 0.40, },
		},
	    },
	    extensions = {
		file_browser = {
		    hidden = true,
		    no_ignore = true,
		    disable_devicons = true,
		    grouped = true,
		    git_status = false,
		    layout_config = { preview_width = 0.40, },
		},
	    },
	})
	require('telescope').load_extension('file_browser')

	vim.api.nvim_create_autocmd({ "FileType", "BufWinEnter" }, {
	    pattern = "*",
	    callback = function(args)
		if vim.bo[args.buf].filetype == "TelescopeResults" then
		    vim.schedule(function()
			local win = vim.fn.bufwinid(args.buf)
			if win ~= -1 then
			    vim.wo[win].number = true
			    vim.wo[win].relativenumber = true
			end
		    end)
		end
	    end,
	})

	local builtin = require('telescope.builtin')
	local global_cwd = (vim.uv or vim.loop).cwd()

	vim.keymap.set('n', '<leader>f', function()
		builtin.find_files({ cwd = global_cwd })
	end, { desc = 'Telescope find files' })
	
	vim.keymap.set('n', '<leader>g', function()
		builtin.live_grep({ cwd = global_cwd })
	end, { desc = 'Telescope live grep' })

	vim.keymap.set('n', '<leader>b', builtin.oldfiles, { desc = 'Telescope buffers' })

	vim.keymap.set('n', '<leader>e', function()
	    require("telescope").extensions.file_browser.file_browser({
		path = "%:p:h",
		select_buffer = true,
	    })
	end, { desc = 'Telescope file browser' })
    end,
}


