return {
    {
	"williamboman/mason.nvim",
	config = true,
    },
    {
	"williamboman/mason-lspconfig.nvim",
	dependencies = { "williamboman/mason.nvim" },
	config = function()
	    require("mason-lspconfig").setup({
		ensure_installed = { "html", "cssls", "ts_ls", "emmet_ls", "ty",
				     "ruff", "jedi_language_server", },

		automatic_enable = false,
	    })
	end,
    },
    {
	"WhoIsSethDaniel/mason-tool-installer.nvim",
	dependencies = { "williamboman/mason.nvim" },
	config = function()
	    require("mason-tool-installer").setup({
		ensure_installed = { "tree-sitter-cli" },
		run_on_start = true,
	    })
	end,
    },
}
