return {
    "hrsh7th/nvim-cmp",
    event = "InsertEnter",
    dependencies = {
	"hrsh7th/cmp-buffer",
	"hrsh7th/cmp-path",
	"hrsh7th/cmp-nvim-lsp",
    },
    config = function()
	local cmp = require("cmp")
	cmp.setup({
	    window = {
		documentation = cmp.config.window.bordered({
		    border = "rounded",
		    winhighlight = "Normal:CmpDoc,FloatBorder:CmpDocBorder,CursorLine:PmenuSel,Search:None",
		}),
	    },
	    formatting = {
		format = function(entry, vim_item)
		    vim_item.menu = nil
		    -- vim_item.kind = ""
		    return vim_item
		end,
	    },
	    completion = {
		autocomplete = false,
	    },
	    sources = {
		{
		    name = "nvim_lsp",
		    priority = 10000,
			--    entry_filter = function(entry, ctx)
			-- local completion_item = entry:get_completion_item()
			-- return completion_item.insertTextFormat == 2 or
			--     string.match(completion_item.label, "~$") ~= nil
			--    end,
		},
		{ name = "path", priority = 500 },
		{ name = "buffer", priority = 250, keyword_length = 4 },
	    }, 
	    
	    mapping = cmp.mapping.preset.insert({
		["<C-f>"] = cmp.mapping(function(fallback)
		    if cmp.visible() then
			for _ = 1, 10 do
			    cmp.select_next_item()
			end
		    else
			fallback()
		    end
		end, { "i" }),
		["<C-b>"] = cmp.mapping(function(fallback)
		    if cmp.visible() then
			for _ = 1, 10 do
			    cmp.select_prev_item()
			end
		    else
			fallback()
		    end
		end, { "i" }),
		["<C-n>"] = cmp.mapping.select_next_item(),
		["<C-p>"] = cmp.mapping.select_prev_item(),
		["<C-a>"] = cmp.mapping.abort(),
		["<CR>"] = cmp.mapping.confirm({ select = false }),
		["<C-l>"] = cmp.mapping.complete(),
		["<C-u>"] = cmp.mapping.scroll_docs(-5),
		["<C-d>"] = cmp.mapping.scroll_docs(5),
	    }),
	})
    end,
}
