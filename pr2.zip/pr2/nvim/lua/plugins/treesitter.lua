return {
    'nvim-treesitter/nvim-treesitter',
    branch = "main",
    build = ":TSUpdate",
    config = function()
	require("nvim-treesitter").setup({
	    install_dir = vim.fn.stdpath("data") .. "/site",
	})

	require("nvim-treesitter").install({
	    "lua", "tsx", "typescript", "javascript", "css", "html", "python", "c", "cpp",
	})

	vim.api.nvim_create_autocmd("FileType", {
	    pattern = { "lua", "tsx", "typescript", "javascript", "css", "html", "python", "c", "cpp" },
	    callback = function()
		vim.treesitter.start()
		vim.bo.indentexpr = "v:lua.require'nvim-treesitter'.indentexpr()"
	    end,
	})
    end
}
