return {
    "neovim/nvim-lspconfig",
    dependencies = { "hrsh7th/cmp-nvim-lsp" },
    config = function()
	local capabilities = require("cmp_nvim_lsp").default_capabilities()

	local mason_bin = vim.fn.stdpath("data") .. "/mason/bin/"

	vim.lsp.config("emmet_ls", {
	    capabilities = capabilities,
	    cmd = { mason_bin .. "emmet-ls.cmd", "--stdio" },
	    filetypes = { "html", "css", "javascriptreact", "typescriptreact", "javascript", "scss", "sass" },
	})

	vim.lsp.config("html", { capabilities = capabilities, })
	vim.lsp.config("cssls", { capabilities = capabilities })
	vim.lsp.config("ts_ls", { capabilities = capabilities })

	vim.lsp.config("jedi_language_server", {
	    capabilities = capabilities,
	    init_options = {
		diagnostics = { enable = true, },
	    },
	})

	vim.lsp.config('ty', {
	    cmd = { 'ty', 'server' },
	    filetypes = { 'python' },
	    root_markers = { 'pyproject.toml', 'ty.toml', '.git' },

	    on_attach = function(client, bufnr)
		vim.lsp.semantic_tokens.enable(false, {
		    bufnr = bufnr,
		    client_id = client.id,
		})
		client.server_capabilities.definitionProvider = false
		client.server_capabilities.declarationProvider = false
		client.server_capabilities.typeDefinitionProvider = false
		client.server_capabilities.referencesProvider = false
		client.server_capabilities.completionProvider = false
	    end,

	    on_init = function(client)
		client.server_capabilities.hoverProvider = false
		client.server_capabilities.signatureHelpProvider = false
		client.server_capabilities.completionProvider = false
	    end,

	    settings = {
		ty = {
		    -- ty language server settings go here
		}
	    },
	})

	vim.lsp.config("ruff", {
	    init_options = {
		settings = {
		    lint = {
			ignore = {
			    "I001",
			},
		    },
		},
	    },
	    on_init = function(client)
		client.server_capabilities.hoverProvider = false
	    end,
	})

	vim.lsp.enable({ "html", "cssls", "ts_ls", "emmet_ls", "ruff",
			"jedi_language_server", "ty", })

    end,
}
