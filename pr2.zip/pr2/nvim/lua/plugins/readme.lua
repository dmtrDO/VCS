return {
    "iamcco/markdown-preview.nvim",
    cmd = { "MarkdownPreviewToggle", "MarkdownPreview", "MarkdownPreviewStop" },
    build = "cd app && npm install",
    init = function()
	vim.g.mkdp_filetypes = { "markdown" }

	_G.open_markdown_preview = function(url)
	    vim.fn.jobstart({ "explorer.exe", url }, { detach = true })
	end

	vim.cmd([[
      function! OpenMarkdownPreview(url)
      call v:lua.open_markdown_preview(a:url)
      endfunction
      ]])
	vim.g.mkdp_browserfunc = "OpenMarkdownPreview"
    end,
    ft = { "markdown" },
    keys = {
	{ "<leader>mp", "<cmd>MarkdownPreviewToggle<cr>", ft = "markdown", desc = "Markdown Preview Toggle" },
    },
}
