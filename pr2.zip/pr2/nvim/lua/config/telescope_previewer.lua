local api = vim.api
local Path = require "plenary.path"

local function format_date(mtime_sec)
    return os.date("%d-%m-%y  %H:%M:%S", mtime_sec)
end

-- Formats first chunk of file as "0x23 0x3a" raw byte streams
local function format_binary_to_hex(filepath)
    local f = io.open(filepath, "rb")
    if not f then return { "Error opening file" } end
    
    -- Read first 1024 bytes to keep the preview fast
    local bytes = f:read(1024)
    f:close()
    if not bytes then return { "Empty file" } end

    local lines = {}
    local current_line = {}
    local bytes_per_line = 12  -- Number of hex values per line

    for i = 1, #bytes do
        local byte = string.byte(bytes, i)
        table.insert(current_line, string.format("0x%02x", byte))
        
        if i % bytes_per_line == 0 then
            table.insert(lines, table.concat(current_line, " "))
            current_line = {}
        end
    end

    if #current_line > 0 then
        table.insert(lines, table.concat(current_line, " "))
    end

    return lines
end

local function handle_directory_preview(filepath, bufnr, opts)
    require("plenary.scandir").ls_async(filepath, {
	hidden = true,
	group_directories_first = true,
	on_exit = vim.schedule_wrap(function(data, sections)
	    local lines = {}
	    local is_win = Path.path.sep == "\\"
	    local size_idx = 2
	    local name_idx = is_win and 4 or 6
	    local pending = #data

	    if pending == 0 then
		api.nvim_buf_set_lines(bufnr, 0, -1, false, {})
		if opts.callback then
		    opts.callback(bufnr)
		end
		return
	    end

	    for i, line in ipairs(data) do
		local s = sections[i]
		local size = line:sub(s[size_idx].start_index, s[size_idx].end_index)
		local name = line:sub(s[name_idx].start_index, s[name_idx].end_index)
		local full_path = filepath .. Path.path.sep .. vim.trim(name)

		vim.uv.fs_stat(full_path, vim.schedule_wrap(function(_, stat)
		    local date = stat and format_date(stat.mtime.sec) or ""
		    lines[i] = string.format("%-20s %-5s %s", name, size, date)
		    lines[i] = string.format("%-38s %-5s", name, size)
		    pending = pending - 1
		    if pending == 0 then
			api.nvim_buf_set_lines(bufnr, 0, -1, false, lines)
			if opts.callback then
			    opts.callback(bufnr)
			end
		    end
		end))
	    end
	end),
    })
end

return function()
    local utils = require "telescope.utils"
    local original_maker = require("telescope.config").values.buffer_previewer_maker
    return function(filepath, bufnr, opts)
	opts = opts or {}
	filepath = utils.path_expand(filepath)
	vim.uv.fs_stat(filepath, function(_, stat)
	    if not stat then
		return
	    end
	    if stat.type == "directory" then
		handle_directory_preview(filepath, bufnr, opts)
	    else
		-- Check if file is binary
		local is_binary = false
		local f = io.open(filepath, "rb")
		if f then
		    local bytes = f:read(1024)
		    if bytes then
			is_binary = bytes:find("\0", 1, true) ~= nil
		    end
		    f:close()
		end

		if is_binary then
		    local hex_lines = format_binary_to_hex(filepath)
		    vim.schedule(function()
			api.nvim_buf_set_lines(bufnr, 0, -1, false, hex_lines)
			if opts.callback then
			    opts.callback(bufnr)
			end
		    end)
		else
		    vim.schedule(function()
			original_maker(filepath, bufnr, opts)
		    end)
		end
	    end
	end)
    end
end
