vim.g.netrw_bufsettings = "noma nomod nonu nobl nowrap ro rnu"
vim.g.netrw_liststyle = 1
vim.g.netrw_sort_by = "exten"
vim.g.netrw_sizestyle = "H"
vim.g.netrw_timefmt = "  %d-%m-%y  %H:%M:%S"
vim.opt.number = true
vim.opt.cursorline = true
vim.opt.relativenumber = true
vim.opt.shiftwidth = 4
vim.opt.shellcmdflag = '-c'
vim.opt.shellxquote = ' '
vim.opt.autochdir = false
vim.opt.clipboard = "unnamedplus"
vim.opt.undofile = true

vim.opt.foldmethod = "expr"
vim.opt.foldexpr = "v:lua.vim.treesitter.foldexpr()"
vim.opt.foldenable = true
vim.opt.foldlevelstart = 99

vim.diagnostic.config({
    float = {
	border = "rounded",
	max_width = math.floor(vim.o.columns * 0.8),
	max_height = math.floor(vim.o.lines * 0.6),
	source = true,
    },
})

vim.o.autoread = true
vim.api.nvim_create_autocmd({ "FocusGained", "BufEnter", "CursorHold", "CursorHoldI" }, {
    pattern = "*",
    callback = function()
	if vim.fn.getcmdwintype() == "" then
	    vim.cmd("checktime")
	end
    end,
})
