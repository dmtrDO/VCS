vim.g.mapleader = " "
vim.keymap.set("n", "<leader>cd", vim.cmd.Ex)
vim.keymap.set("n", "<C-y>", "10<C-y>", { noremap = true })
vim.keymap.set("n", "<C-e>", "10<C-e>", { noremap = true })
vim.keymap.set('n', '<leader>d', vim.diagnostic.open_float, { desc = 'Show diagnostic' })


vim.keymap.set("n", "<leader>1", "<cmd>1ToggleTerm dir=%:p:h<CR>", { desc = "Terminal 1" })
vim.keymap.set("n", "<leader>2", "<cmd>2ToggleTerm dir=%:p:h<CR>", { desc = "Terminal 2" })
vim.keymap.set("n", "<leader>3", "<cmd>3ToggleTerm dir=%:p:h<CR>", { desc = "Terminal 3" })

local term_count = 4

vim.keymap.set("n", "<leader>th", function()
    term_count = term_count + 1
    vim.cmd(term_count .. "ToggleTerm direction=horizontal dir=%:p:h")
end, { desc = "New horizontal terminal" })


vim.keymap.set("n", "<leader>jd", vim.lsp.buf.definition, {})
vim.keymap.set("n", "<leader>jr", vim.lsp.buf.references, {})
vim.keymap.set("n", "<leader>ca", vim.lsp.buf.code_action, {})

vim.keymap.set("n", "]d", function()
    vim.diagnostic.jump({count = 1, float=true})
end, {desc = "Go to next diagnostic"})

vim.keymap.set("n", "[d", function()
    vim.diagnostic.jump({count = -1, float=true})
end, {desc = "Go to previous diagnostic"})


local hover_opts = {
    border = "rounded",
    max_width = math.floor(vim.o.columns * 0.8),
    max_height = math.floor(vim.o.lines * 0.6),
    source = true,
}

vim.keymap.set("n", "K", function()
    vim.lsp.buf.hover(hover_opts)
end, {})

vim.keymap.set({"i", "n"}, "<C-k>", function()
    vim.lsp.buf.signature_help(hover_opts)
end, {})

