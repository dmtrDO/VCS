
vim.cmd("highlight clear")
if vim.fn.exists("syntax_on") then
    vim.cmd("syntax reset")
end
vim.o.background = "dark"
vim.o.termguicolors = true
vim.g.colors_name = "pymatch"

local colors = {
    bg          = "#1e1e1e",
    fg          = "#FFFFFF",
    green       = "#A6DB28", -- functions, classes, booleans
    emerald     = "#50FA7B", -- keywords, storage, types, magic methods
    light_green = "#bff8bf", -- numbers, strings
    aqua        = "#00f5ff", -- builtin functions, def/class keywords
    blue        = "#00c3ff", -- parameters
    yellow      = "#FFEA00", -- comments
    white       = "#FFFFFF", -- punctuation
    gray        = "#5c6370", -- non-highlighted fallback
    popup 	= "#313244", -- hints, popups
}

local hl = vim.api.nvim_set_hl

-- ============================================================
-- General editor UI
-- ============================================================
hl(0, "Normal",       { fg = colors.fg, bg = colors.bg })
hl(0, "NormalFloat",  { fg = colors.fg, bg = colors.bg })
hl(0, "CursorLine",   { bg = "#2a2a2a" })
hl(0, "CursorLineNr", { fg = colors.green, bold = true })
hl(0, "LineNr",       { fg = colors.gray })
hl(0, "Visual",       { bg = "#3a3d41" })
hl(0, "Pmenu",        { fg = colors.fg, bg = "#252526" })
hl(0, "Pmenu",        { fg = colors.fg, bg = colors.popup })
hl(0, "PmenuSel",     { fg = colors.bg, bg = colors.aqua })
hl(0, "StatusLine",   { fg = colors.fg, bg = "#252526" })
hl(0, "VertSplit",    { fg = "#3a3a3a" })
hl(0, "MatchParen",   { fg = colors.yellow, bold = true })

-- ============================================================
-- Base syntax groups (fallback for non-treesitter / other langs)
-- ============================================================
hl(0, "Comment",    { fg = colors.yellow, italic = true })
hl(0, "String",     { fg = colors.light_green, italic = true })
hl(0, "Number",     { fg = colors.light_green })
hl(0, "Boolean",    { fg = colors.green })
hl(0, "Function",   { fg = colors.green })
hl(0, "Identifier", { fg = colors.white })
hl(0, "Statement",  { fg = colors.emerald })
hl(0, "Keyword",    { fg = colors.emerald })
hl(0, "Type",       { fg = colors.emerald })
hl(0, "Constant",   { fg = colors.emerald })
hl(0, "PreProc",    { fg = colors.emerald })
hl(0, "Special",    { fg = colors.aqua })
hl(0, "Delimiter",  { fg = colors.white })
hl(0, "Operator",   { fg = colors.white })

-- ============================================================
-- Treesitter groups (Python-focused, via @-captures)
-- ============================================================

hl(0, "@module.python",     { fg = colors.white })

-- Functions / classes -> Green
hl(0, "@function",          { fg = colors.green })
hl(0, "@function.call.python",     { fg = colors.aqua })
hl(0, "@constructor",       { fg = colors.green })   -- class names
hl(0, "@function.magic",    { fg = colors.emerald })  -- __init__ etc (if provided by parser)

-- Keywords / storage / types -> Emerald
hl(0, "@keyword",           { fg = colors.emerald })
hl(0, "@keyword.function",  { fg = colors.emerald })
hl(0, "@keyword.return",    { fg = colors.emerald })
hl(0, "@keyword.import",    { fg = colors.emerald })
hl(0, "@keyword.operator",  { fg = colors.emerald })
hl(0, "@keyword.repeat",    { fg = colors.emerald })
hl(0, "@keyword.conditional",{ fg = colors.emerald })
hl(0, "@type",               { fg = colors.emerald })
hl(0, "@variable.builtin",   { fg = colors.emerald }) -- self, cls
hl(0, "@constant.builtin",   { fg = colors.emerald }) -- None
hl(0, "@string.escape",      { fg = colors.emerald })

-- Numbers / strings -> Light green
hl(0, "@number",         { fg = colors.light_green })
hl(0, "@float",          { fg = colors.light_green })
hl(0, "@string",         { fg = colors.light_green, italic = true })

-- Booleans -> Green (grouped w/ functions per your scheme)
hl(0, "@boolean",        { fg = colors.green })

-- Builtin functions / def & class keyword / storage type -> Aqua
hl(0, "@function.builtin", { fg = colors.aqua })
hl(0, "@keyword.function.builtin", { fg = colors.aqua })
hl(0, "@storageclass",     { fg = colors.aqua, italic = true })

-- Parameters -> Blue (italic)
hl(0, "@variable.parameter", { fg = colors.blue, italic = true })

-- Comments -> Yellow (italic)
hl(0, "@comment", { fg = colors.yellow, italic = true })

-- Punctuation / misc variables -> White
hl(0, "@punctuation.bracket",   { fg = colors.white })
hl(0, "@punctuation.delimiter", { fg = colors.white })
hl(0, "@punctuation.special",   { fg = colors.white })
hl(0, "@variable",              { fg = colors.white })
hl(0, "@attribute",             { fg = colors.white })

vim.api.nvim_set_hl(0, "NormalFloat", { bg = colors.popup })
vim.api.nvim_set_hl(0, "FloatBorder", { bg = colors.popup, fg = "#89b4fa" })

-- diagnostic float text groups — force bg to match, remove standalone bg
vim.api.nvim_set_hl(0, "DiagnosticFloatingError", { bg = colors.popup })
vim.api.nvim_set_hl(0, "DiagnosticFloatingWarn", { bg = colors.popup })
vim.api.nvim_set_hl(0, "DiagnosticFloatingInfo", { bg = colors.popup })
vim.api.nvim_set_hl(0, "DiagnosticFloatingHint", { bg = colors.popup })

-- common cause: CursorLine bleeding into floating windows
vim.api.nvim_set_hl(0, "CursorLine", { bg = "NONE" })

-- autocompletion (cmp) windows
vim.api.nvim_set_hl(0, "CmpDoc", { bg = "#1e1e2e", fg = "#cdd6f4" })
vim.api.nvim_set_hl(0, "CmpDocBorder", { bg = "#1e1e2e", fg = "#89b4fa" })

